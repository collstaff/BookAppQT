/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../Wed_29_BookStoreApp/mainwindow.h"
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_MainWindow_t {
    uint offsetsAndSizes[34];
    char stringdata0[11];
    char stringdata1[17];
    char stringdata2[1];
    char stringdata3[33];
    char stringdata4[15];
    char stringdata5[25];
    char stringdata6[31];
    char stringdata7[22];
    char stringdata8[25];
    char stringdata9[25];
    char stringdata10[19];
    char stringdata11[21];
    char stringdata12[13];
    char stringdata13[16];
    char stringdata14[19];
    char stringdata15[22];
    char stringdata16[14];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_MainWindow_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 16),  // "search_inventory"
        QT_MOC_LITERAL(28, 0),  // ""
        QT_MOC_LITERAL(29, 32),  // "on_actionHardware_Info_triggered"
        QT_MOC_LITERAL(62, 14),  // "showHelpWindow"
        QT_MOC_LITERAL(77, 24),  // "on_actionNotes_triggered"
        QT_MOC_LITERAL(102, 30),  // "on_actionPreferences_triggered"
        QT_MOC_LITERAL(133, 21),  // "on_addUserBtn_clicked"
        QT_MOC_LITERAL(155, 24),  // "on_deleteUserBtn_clicked"
        QT_MOC_LITERAL(180, 24),  // "on_changePassBtn_clicked"
        QT_MOC_LITERAL(205, 18),  // "addBookToInventory"
        QT_MOC_LITERAL(224, 20),  // "addBookToListTextBox"
        QT_MOC_LITERAL(245, 12),  // "saveListToDb"
        QT_MOC_LITERAL(258, 15),  // "exportListToTxt"
        QT_MOC_LITERAL(274, 18),  // "removeBookFromList"
        QT_MOC_LITERAL(293, 21),  // "addBookToShoppingList"
        QT_MOC_LITERAL(315, 13)   // "purchaseBooks"
    },
    "MainWindow",
    "search_inventory",
    "",
    "on_actionHardware_Info_triggered",
    "showHelpWindow",
    "on_actionNotes_triggered",
    "on_actionPreferences_triggered",
    "on_addUserBtn_clicked",
    "on_deleteUserBtn_clicked",
    "on_changePassBtn_clicked",
    "addBookToInventory",
    "addBookToListTextBox",
    "saveListToDb",
    "exportListToTxt",
    "removeBookFromList",
    "addBookToShoppingList",
    "purchaseBooks"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_MainWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  104,    2, 0x08,    1 /* Private */,
       3,    0,  105,    2, 0x08,    2 /* Private */,
       4,    0,  106,    2, 0x08,    3 /* Private */,
       5,    0,  107,    2, 0x08,    4 /* Private */,
       6,    0,  108,    2, 0x08,    5 /* Private */,
       7,    0,  109,    2, 0x08,    6 /* Private */,
       8,    0,  110,    2, 0x08,    7 /* Private */,
       9,    0,  111,    2, 0x08,    8 /* Private */,
      10,    0,  112,    2, 0x08,    9 /* Private */,
      11,    0,  113,    2, 0x08,   10 /* Private */,
      12,    0,  114,    2, 0x08,   11 /* Private */,
      13,    0,  115,    2, 0x08,   12 /* Private */,
      14,    0,  116,    2, 0x08,   13 /* Private */,
      15,    0,  117,    2, 0x08,   14 /* Private */,
      16,    0,  118,    2, 0x08,   15 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSizes,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'search_inventory'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionHardware_Info_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showHelpWindow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionNotes_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionPreferences_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_addUserBtn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_deleteUserBtn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_changePassBtn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'addBookToInventory'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'addBookToListTextBox'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'saveListToDb'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'exportListToTxt'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'removeBookFromList'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'addBookToShoppingList'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'purchaseBooks'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->search_inventory(); break;
        case 1: _t->on_actionHardware_Info_triggered(); break;
        case 2: _t->showHelpWindow(); break;
        case 3: _t->on_actionNotes_triggered(); break;
        case 4: _t->on_actionPreferences_triggered(); break;
        case 5: _t->on_addUserBtn_clicked(); break;
        case 6: _t->on_deleteUserBtn_clicked(); break;
        case 7: _t->on_changePassBtn_clicked(); break;
        case 8: _t->addBookToInventory(); break;
        case 9: _t->addBookToListTextBox(); break;
        case 10: _t->saveListToDb(); break;
        case 11: _t->exportListToTxt(); break;
        case 12: _t->removeBookFromList(); break;
        case 13: _t->addBookToShoppingList(); break;
        case 14: _t->purchaseBooks(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 15;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
