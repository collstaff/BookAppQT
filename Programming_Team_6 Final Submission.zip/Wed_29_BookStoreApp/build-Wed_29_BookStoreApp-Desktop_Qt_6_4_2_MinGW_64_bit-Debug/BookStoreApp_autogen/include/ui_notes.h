/********************************************************************************
** Form generated from reading UI file 'notes.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NOTES_H
#define UI_NOTES_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_Notes
{
public:
    QTextEdit *notesTxt;
    QLabel *notesLbl;
    QPushButton *backBtn;
    QPushButton *exportBtn;

    void setupUi(QDialog *Notes)
    {
        if (Notes->objectName().isEmpty())
            Notes->setObjectName("Notes");
        Notes->resize(431, 325);
        notesTxt = new QTextEdit(Notes);
        notesTxt->setObjectName("notesTxt");
        notesTxt->setGeometry(QRect(0, 30, 431, 241));
        notesLbl = new QLabel(Notes);
        notesLbl->setObjectName("notesLbl");
        notesLbl->setGeometry(QRect(160, 10, 91, 16));
        notesLbl->setAlignment(Qt::AlignCenter);
        backBtn = new QPushButton(Notes);
        backBtn->setObjectName("backBtn");
        backBtn->setGeometry(QRect(250, 290, 80, 24));
        exportBtn = new QPushButton(Notes);
        exportBtn->setObjectName("exportBtn");
        exportBtn->setGeometry(QRect(90, 290, 80, 24));

        retranslateUi(Notes);
        QObject::connect(backBtn, &QPushButton::clicked, Notes, qOverload<>(&QDialog::close));
        QObject::connect(exportBtn, SIGNAL(clicked()), Notes, SLOT(exportNotes()));

        QMetaObject::connectSlotsByName(Notes);
    } // setupUi

    void retranslateUi(QDialog *Notes)
    {
        Notes->setWindowTitle(QCoreApplication::translate("Notes", "Dialog", nullptr));
        notesLbl->setText(QCoreApplication::translate("Notes", "Notes", nullptr));
        backBtn->setText(QCoreApplication::translate("Notes", "Back", nullptr));
        exportBtn->setText(QCoreApplication::translate("Notes", "Export To File", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Notes: public Ui_Notes {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NOTES_H
