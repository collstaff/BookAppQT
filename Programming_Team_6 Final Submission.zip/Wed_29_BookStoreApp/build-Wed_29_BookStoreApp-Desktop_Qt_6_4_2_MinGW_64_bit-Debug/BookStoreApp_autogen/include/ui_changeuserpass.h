/********************************************************************************
** Form generated from reading UI file 'changeuserpass.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHANGEUSERPASS_H
#define UI_CHANGEUSERPASS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ChangeUserPass
{
public:
    QLabel *changeUserLbl;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *changeUsernameLbl;
    QTextEdit *changeUserTxt;
    QLabel *changePassLbl;
    QTextEdit *newPassTxt;
    QPushButton *changeUserCancelBtn;
    QPushButton *changeUserOkBtn;

    void setupUi(QDialog *ChangeUserPass)
    {
        if (ChangeUserPass->objectName().isEmpty())
            ChangeUserPass->setObjectName("ChangeUserPass");
        ChangeUserPass->resize(400, 300);
        changeUserLbl = new QLabel(ChangeUserPass);
        changeUserLbl->setObjectName("changeUserLbl");
        changeUserLbl->setGeometry(QRect(90, 10, 211, 61));
        QFont font;
        font.setPointSize(20);
        changeUserLbl->setFont(font);
        verticalLayoutWidget = new QWidget(ChangeUserPass);
        verticalLayoutWidget->setObjectName("verticalLayoutWidget");
        verticalLayoutWidget->setGeometry(QRect(110, 80, 160, 111));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        changeUsernameLbl = new QLabel(verticalLayoutWidget);
        changeUsernameLbl->setObjectName("changeUsernameLbl");

        verticalLayout->addWidget(changeUsernameLbl);

        changeUserTxt = new QTextEdit(verticalLayoutWidget);
        changeUserTxt->setObjectName("changeUserTxt");

        verticalLayout->addWidget(changeUserTxt);

        changePassLbl = new QLabel(verticalLayoutWidget);
        changePassLbl->setObjectName("changePassLbl");

        verticalLayout->addWidget(changePassLbl);

        newPassTxt = new QTextEdit(verticalLayoutWidget);
        newPassTxt->setObjectName("newPassTxt");

        verticalLayout->addWidget(newPassTxt);

        changeUserCancelBtn = new QPushButton(ChangeUserPass);
        changeUserCancelBtn->setObjectName("changeUserCancelBtn");
        changeUserCancelBtn->setGeometry(QRect(70, 210, 111, 24));
        changeUserOkBtn = new QPushButton(ChangeUserPass);
        changeUserOkBtn->setObjectName("changeUserOkBtn");
        changeUserOkBtn->setGeometry(QRect(200, 210, 111, 24));

        retranslateUi(ChangeUserPass);
        QObject::connect(changeUserCancelBtn, &QPushButton::clicked, ChangeUserPass, qOverload<>(&QDialog::close));
        QObject::connect(changeUserOkBtn, SIGNAL(clicked()), ChangeUserPass, SLOT(changeUserPassword()));

        QMetaObject::connectSlotsByName(ChangeUserPass);
    } // setupUi

    void retranslateUi(QDialog *ChangeUserPass)
    {
        ChangeUserPass->setWindowTitle(QCoreApplication::translate("ChangeUserPass", "Dialog", nullptr));
        changeUserLbl->setText(QCoreApplication::translate("ChangeUserPass", "Change Password", nullptr));
        changeUsernameLbl->setText(QCoreApplication::translate("ChangeUserPass", "Username", nullptr));
        changePassLbl->setText(QCoreApplication::translate("ChangeUserPass", "New Username", nullptr));
        changeUserCancelBtn->setText(QCoreApplication::translate("ChangeUserPass", "Cancel", nullptr));
        changeUserOkBtn->setText(QCoreApplication::translate("ChangeUserPass", "Change Password", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ChangeUserPass: public Ui_ChangeUserPass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHANGEUSERPASS_H
