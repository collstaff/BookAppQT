/********************************************************************************
** Form generated from reading UI file 'logindialog.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINDIALOG_H
#define UI_LOGINDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_logindialog
{
public:
    QLabel *loginTitle;
    QLabel *userLbl;
    QLabel *passLbl;
    QPushButton *loginBtn;
    QTextEdit *usernameTxt;
    QTextEdit *passwordTxt;

    void setupUi(QDialog *logindialog)
    {
        if (logindialog->objectName().isEmpty())
            logindialog->setObjectName("logindialog");
        logindialog->resize(284, 217);
        loginTitle = new QLabel(logindialog);
        loginTitle->setObjectName("loginTitle");
        loginTitle->setGeometry(QRect(100, 0, 71, 41));
        QFont font;
        font.setPointSize(20);
        loginTitle->setFont(font);
        userLbl = new QLabel(logindialog);
        userLbl->setObjectName("userLbl");
        userLbl->setGeometry(QRect(70, 50, 61, 16));
        passLbl = new QLabel(logindialog);
        passLbl->setObjectName("passLbl");
        passLbl->setGeometry(QRect(70, 110, 61, 21));
        loginBtn = new QPushButton(logindialog);
        loginBtn->setObjectName("loginBtn");
        loginBtn->setGeometry(QRect(100, 170, 80, 24));
        usernameTxt = new QTextEdit(logindialog);
        usernameTxt->setObjectName("usernameTxt");
        usernameTxt->setGeometry(QRect(70, 70, 131, 31));
        passwordTxt = new QTextEdit(logindialog);
        passwordTxt->setObjectName("passwordTxt");
        passwordTxt->setGeometry(QRect(70, 130, 131, 31));

        retranslateUi(logindialog);
        QObject::connect(loginBtn, SIGNAL(clicked()), logindialog, SLOT(logUserIn()));

        QMetaObject::connectSlotsByName(logindialog);
    } // setupUi

    void retranslateUi(QDialog *logindialog)
    {
        logindialog->setWindowTitle(QCoreApplication::translate("logindialog", "Dialog", nullptr));
        loginTitle->setText(QCoreApplication::translate("logindialog", "Login", nullptr));
        userLbl->setText(QCoreApplication::translate("logindialog", "Username", nullptr));
        passLbl->setText(QCoreApplication::translate("logindialog", "Password", nullptr));
        loginBtn->setText(QCoreApplication::translate("logindialog", "Log In", nullptr));
    } // retranslateUi

};

namespace Ui {
    class logindialog: public Ui_logindialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINDIALOG_H
