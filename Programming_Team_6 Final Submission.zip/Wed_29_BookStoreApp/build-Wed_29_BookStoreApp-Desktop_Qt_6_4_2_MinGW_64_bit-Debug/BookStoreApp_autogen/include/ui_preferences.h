/********************************************************************************
** Form generated from reading UI file 'preferences.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PREFERENCES_H
#define UI_PREFERENCES_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Preferences
{
public:
    QCheckBox *changeFontChk;
    QCheckBox *fontWeightChk;
    QLabel *prefLbl;
    QPushButton *backBtn;
    QPushButton *applyBtn;

    void setupUi(QDialog *Preferences)
    {
        if (Preferences->objectName().isEmpty())
            Preferences->setObjectName("Preferences");
        Preferences->resize(284, 166);
        changeFontChk = new QCheckBox(Preferences);
        changeFontChk->setObjectName("changeFontChk");
        changeFontChk->setGeometry(QRect(100, 60, 101, 22));
        fontWeightChk = new QCheckBox(Preferences);
        fontWeightChk->setObjectName("fontWeightChk");
        fontWeightChk->setGeometry(QRect(100, 80, 141, 22));
        prefLbl = new QLabel(Preferences);
        prefLbl->setObjectName("prefLbl");
        prefLbl->setGeometry(QRect(70, 10, 141, 41));
        QFont font;
        font.setPointSize(20);
        prefLbl->setFont(font);
        backBtn = new QPushButton(Preferences);
        backBtn->setObjectName("backBtn");
        backBtn->setGeometry(QRect(40, 120, 80, 24));
        applyBtn = new QPushButton(Preferences);
        applyBtn->setObjectName("applyBtn");
        applyBtn->setGeometry(QRect(170, 120, 80, 24));

        retranslateUi(Preferences);
        QObject::connect(backBtn, &QPushButton::clicked, Preferences, qOverload<>(&QDialog::close));
        QObject::connect(applyBtn, SIGNAL(clicked()), Preferences, SLOT(updateSettings()));

        QMetaObject::connectSlotsByName(Preferences);
    } // setupUi

    void retranslateUi(QDialog *Preferences)
    {
        Preferences->setWindowTitle(QCoreApplication::translate("Preferences", "Dialog", nullptr));
        changeFontChk->setText(QCoreApplication::translate("Preferences", "Use Alt Font", nullptr));
        fontWeightChk->setText(QCoreApplication::translate("Preferences", "Increase Font Weight", nullptr));
        prefLbl->setText(QCoreApplication::translate("Preferences", "Preferences", nullptr));
        backBtn->setText(QCoreApplication::translate("Preferences", "Back", nullptr));
        applyBtn->setText(QCoreApplication::translate("Preferences", "Apply", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Preferences: public Ui_Preferences {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PREFERENCES_H
