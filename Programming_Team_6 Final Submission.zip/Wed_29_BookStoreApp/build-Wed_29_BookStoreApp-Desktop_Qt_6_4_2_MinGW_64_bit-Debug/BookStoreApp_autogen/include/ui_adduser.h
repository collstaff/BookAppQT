/********************************************************************************
** Form generated from reading UI file 'adduser.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDUSER_H
#define UI_ADDUSER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AddUser
{
public:
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *addUserNameLbl;
    QTextEdit *addUsernameTxt;
    QLabel *addPassLbl;
    QTextEdit *addPassTxt;
    QLabel *addUserTitle;
    QPushButton *addUserBtn;
    QPushButton *cancelAddBtn;

    void setupUi(QDialog *AddUser)
    {
        if (AddUser->objectName().isEmpty())
            AddUser->setObjectName("AddUser");
        AddUser->resize(400, 300);
        verticalLayoutWidget = new QWidget(AddUser);
        verticalLayoutWidget->setObjectName("verticalLayoutWidget");
        verticalLayoutWidget->setGeometry(QRect(120, 70, 160, 111));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        addUserNameLbl = new QLabel(verticalLayoutWidget);
        addUserNameLbl->setObjectName("addUserNameLbl");

        verticalLayout->addWidget(addUserNameLbl);

        addUsernameTxt = new QTextEdit(verticalLayoutWidget);
        addUsernameTxt->setObjectName("addUsernameTxt");

        verticalLayout->addWidget(addUsernameTxt);

        addPassLbl = new QLabel(verticalLayoutWidget);
        addPassLbl->setObjectName("addPassLbl");

        verticalLayout->addWidget(addPassLbl);

        addPassTxt = new QTextEdit(verticalLayoutWidget);
        addPassTxt->setObjectName("addPassTxt");

        verticalLayout->addWidget(addPassTxt);

        addUserTitle = new QLabel(AddUser);
        addUserTitle->setObjectName("addUserTitle");
        addUserTitle->setGeometry(QRect(140, 10, 121, 41));
        QFont font;
        font.setPointSize(20);
        addUserTitle->setFont(font);
        addUserBtn = new QPushButton(AddUser);
        addUserBtn->setObjectName("addUserBtn");
        addUserBtn->setGeometry(QRect(200, 210, 80, 24));
        cancelAddBtn = new QPushButton(AddUser);
        cancelAddBtn->setObjectName("cancelAddBtn");
        cancelAddBtn->setGeometry(QRect(110, 210, 80, 24));

        retranslateUi(AddUser);
        QObject::connect(cancelAddBtn, &QPushButton::clicked, AddUser, qOverload<>(&QDialog::close));
        QObject::connect(addUserBtn, SIGNAL(clicked()), AddUser, SLOT(addUserToDb()));

        QMetaObject::connectSlotsByName(AddUser);
    } // setupUi

    void retranslateUi(QDialog *AddUser)
    {
        AddUser->setWindowTitle(QCoreApplication::translate("AddUser", "Dialog", nullptr));
        addUserNameLbl->setText(QCoreApplication::translate("AddUser", "Username", nullptr));
        addPassLbl->setText(QCoreApplication::translate("AddUser", "Password", nullptr));
        addUserTitle->setText(QCoreApplication::translate("AddUser", "Add User", nullptr));
        addUserBtn->setText(QCoreApplication::translate("AddUser", "Add", nullptr));
        cancelAddBtn->setText(QCoreApplication::translate("AddUser", "Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AddUser: public Ui_AddUser {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDUSER_H
