/********************************************************************************
** Form generated from reading UI file 'dialogdialog.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGDIALOG_H
#define UI_DIALOGDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_dialogdialog
{
public:
    QGroupBox *groupBox;
    QPushButton *pushButton_login;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label_username;
    QLineEdit *lineEdit_username;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_password;
    QLineEdit *lineEdit_password;
    QPushButton *exitAppBtn;

    void setupUi(QWidget *dialogdialog)
    {
        if (dialogdialog->objectName().isEmpty())
            dialogdialog->setObjectName("dialogdialog");
        dialogdialog->resize(400, 300);
        groupBox = new QGroupBox(dialogdialog);
        groupBox->setObjectName("groupBox");
        groupBox->setGeometry(QRect(50, 50, 291, 191));
        pushButton_login = new QPushButton(groupBox);
        pushButton_login->setObjectName("pushButton_login");
        pushButton_login->setGeometry(QRect(160, 140, 93, 29));
        layoutWidget = new QWidget(groupBox);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(30, 60, 226, 63));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName("horizontalLayout");
        label_username = new QLabel(layoutWidget);
        label_username->setObjectName("label_username");

        horizontalLayout->addWidget(label_username);

        lineEdit_username = new QLineEdit(layoutWidget);
        lineEdit_username->setObjectName("lineEdit_username");

        horizontalLayout->addWidget(lineEdit_username);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        label_password = new QLabel(layoutWidget);
        label_password->setObjectName("label_password");

        horizontalLayout_2->addWidget(label_password);

        lineEdit_password = new QLineEdit(layoutWidget);
        lineEdit_password->setObjectName("lineEdit_password");

        horizontalLayout_2->addWidget(lineEdit_password);


        verticalLayout->addLayout(horizontalLayout_2);

        exitAppBtn = new QPushButton(groupBox);
        exitAppBtn->setObjectName("exitAppBtn");
        exitAppBtn->setGeometry(QRect(30, 140, 93, 29));

        retranslateUi(dialogdialog);
        QObject::connect(exitAppBtn, SIGNAL(clicked()), dialogdialog, SLOT(exitApp()));

        QMetaObject::connectSlotsByName(dialogdialog);
    } // setupUi

    void retranslateUi(QWidget *dialogdialog)
    {
        dialogdialog->setWindowTitle(QCoreApplication::translate("dialogdialog", "Login", nullptr));
        groupBox->setTitle(QCoreApplication::translate("dialogdialog", "LOG IN", nullptr));
        pushButton_login->setText(QCoreApplication::translate("dialogdialog", "Sign in", nullptr));
        label_username->setText(QCoreApplication::translate("dialogdialog", "Username", nullptr));
        label_password->setText(QCoreApplication::translate("dialogdialog", "Password", nullptr));
        exitAppBtn->setText(QCoreApplication::translate("dialogdialog", "Exit", nullptr));
    } // retranslateUi

};

namespace Ui {
    class dialogdialog: public Ui_dialogdialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGDIALOG_H
