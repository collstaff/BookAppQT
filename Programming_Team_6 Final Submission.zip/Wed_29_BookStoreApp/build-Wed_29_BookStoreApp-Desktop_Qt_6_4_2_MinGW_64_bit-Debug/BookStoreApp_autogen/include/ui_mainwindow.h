/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionSearcher;
    QAction *actionAdd_Book;
    QAction *actionAdd_to_Cart;
    QAction *actionHardware_Info;
    QAction *actionNotes;
    QAction *actionPreferences;
    QWidget *centralwidget;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QTabWidget *parentTabWidget;
    QWidget *searchTab;
    QPlainTextEdit *searchOutputTxt_3;
    QWidget *verticalLayoutWidget_8;
    QVBoxLayout *verticalLayout_9;
    QSpacerItem *verticalSpacer;
    QLabel *searchLbl;
    QLineEdit *searchLineEdt;
    QPushButton *searchBtn;
    QPushButton *searchHelp;
    QPushButton *exitBtn;
    QWidget *addBookTab;
    QPushButton *addInvBtn;
    QPushButton *addBookHelp;
    QPushButton *exitBtn_2;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_7;
    QLabel *IsbnLbl;
    QSpacerItem *horizontalSpacer_4;
    QTextEdit *isbnTxt;
    QWidget *layoutWidget2;
    QHBoxLayout *horizontalLayout_11;
    QLabel *bookTitleLbl;
    QSpacerItem *horizontalSpacer_5;
    QTextEdit *bookTitleTxt;
    QWidget *layoutWidget3;
    QHBoxLayout *horizontalLayout_12;
    QLabel *authorLbl;
    QSpacerItem *horizontalSpacer_6;
    QTextEdit *authorTxt;
    QWidget *layoutWidget4;
    QHBoxLayout *horizontalLayout_9;
    QLabel *pubLbl;
    QSpacerItem *horizontalSpacer_7;
    QTextEdit *pubTxt;
    QWidget *layoutWidget5;
    QHBoxLayout *horizontalLayout_10;
    QLabel *pubYearLbl;
    QSpacerItem *horizontalSpacer_8;
    QTextEdit *pubYearTxt;
    QWidget *layoutWidget6;
    QHBoxLayout *horizontalLayout_8;
    QLabel *genreLbl;
    QSpacerItem *horizontalSpacer_9;
    QTextEdit *genreTxt;
    QWidget *layoutWidget7;
    QHBoxLayout *horizontalLayout_15;
    QLabel *descLbl;
    QSpacerItem *horizontalSpacer_12;
    QTextEdit *descTxt;
    QWidget *layoutWidget8;
    QHBoxLayout *horizontalLayout_14;
    QLabel *msrpLbl;
    QSpacerItem *horizontalSpacer_11;
    QTextEdit *msrpTxt;
    QWidget *layoutWidget9;
    QHBoxLayout *horizontalLayout_13;
    QLabel *quantLbl;
    QSpacerItem *horizontalSpacer_10;
    QTextEdit *quantTxt;
    QWidget *addBookListTab;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout;
    QLabel *titleLbl;
    QSpacerItem *horizontalSpacer;
    QLineEdit *titleTxt;
    QPushButton *titleSearchBtn;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_3;
    QListWidget *bookList;
    QPushButton *addBookBtn;
    QPushButton *addBookCartBtn;
    QPushButton *bookListHelp;
    QWidget *verticalLayoutWidget_10;
    QVBoxLayout *verticalLayout_11;
    QLabel *bookListLbl;
    QListWidget *finalBookList;
    QPushButton *removeBookBtn;
    QPushButton *saveListBtn;
    QPushButton *listExportBtn;
    QPushButton *exitBtn_3;
    QWidget *shoppingCartTab;
    QWidget *verticalLayoutWidget_3;
    QVBoxLayout *verticalLayout_4;
    QListWidget *shoppingList;
    QWidget *verticalLayoutWidget_4;
    QVBoxLayout *verticalLayout_5;
    QLabel *subtotalLbl;
    QHBoxLayout *horizontalLayout_4;
    QLineEdit *subTotalTxt;
    QWidget *verticalLayoutWidget_5;
    QVBoxLayout *verticalLayout_6;
    QLabel *taxLbl;
    QHBoxLayout *horizontalLayout_5;
    QLineEdit *taxTxt;
    QWidget *verticalLayoutWidget_6;
    QVBoxLayout *verticalLayout_7;
    QLabel *grandTotalLbl;
    QHBoxLayout *horizontalLayout_6;
    QLineEdit *grandTotalTxt;
    QPushButton *purchaseBtn;
    QPushButton *cartHelp;
    QPushButton *exitBtn_4;
    QWidget *layoutWidget10;
    QHBoxLayout *horizontalLayout_16;
    QLabel *emailLbl;
    QSpacerItem *horizontalSpacer_2;
    QTextEdit *emailTxt;
    QWidget *layoutWidget11;
    QHBoxLayout *horizontalLayout_2;
    QLabel *nameLbl;
    QTextEdit *nameTxt;
    QWidget *adminTab;
    QWidget *verticalLayoutWidget_7;
    QVBoxLayout *verticalLayout_8;
    QPushButton *addUserBtn;
    QPushButton *deleteUserBtn;
    QPushButton *changePassBtn;
    QPushButton *adminHelp;
    QPushButton *exitBtn_5;
    QMenuBar *menubar;
    QMenu *fileMenu;
    QMenu *editList;
    QMenu *menuHelp;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->setEnabled(true);
        MainWindow->resize(591, 429);
        MainWindow->setMinimumSize(QSize(591, 429));
        MainWindow->setMaximumSize(QSize(591, 429));
        actionSearcher = new QAction(MainWindow);
        actionSearcher->setObjectName("actionSearcher");
        actionAdd_Book = new QAction(MainWindow);
        actionAdd_Book->setObjectName("actionAdd_Book");
        actionAdd_to_Cart = new QAction(MainWindow);
        actionAdd_to_Cart->setObjectName("actionAdd_to_Cart");
        actionHardware_Info = new QAction(MainWindow);
        actionHardware_Info->setObjectName("actionHardware_Info");
        actionNotes = new QAction(MainWindow);
        actionNotes->setObjectName("actionNotes");
        actionPreferences = new QAction(MainWindow);
        actionPreferences->setObjectName("actionPreferences");
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(140, 120, 129, 126));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        parentTabWidget = new QTabWidget(centralwidget);
        parentTabWidget->setObjectName("parentTabWidget");
        parentTabWidget->setGeometry(QRect(0, 0, 591, 401));
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(134, 118, 191, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        QBrush brush2(QColor(203, 189, 255, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Light, brush2);
        QBrush brush3(QColor(168, 153, 223, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        QBrush brush4(QColor(67, 59, 95, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush4);
        QBrush brush5(QColor(89, 79, 127, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        QBrush brush6(QColor(255, 255, 255, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush6);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush);
        QBrush brush7(QColor(194, 186, 223, 255));
        brush7.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush7);
        QBrush brush8(QColor(255, 255, 220, 255));
        brush8.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush8);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        QBrush brush9(QColor(0, 0, 0, 127));
        brush9.setStyle(Qt::SolidPattern);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Active, QPalette::PlaceholderText, brush9);
#endif
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        QBrush brush10(QColor(240, 240, 240, 255));
        brush10.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush10);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush6);
        QBrush brush11(QColor(227, 227, 227, 255));
        brush11.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush11);
        QBrush brush12(QColor(160, 160, 160, 255));
        brush12.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush12);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush12);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush10);
        QBrush brush13(QColor(105, 105, 105, 255));
        brush13.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush13);
        QBrush brush14(QColor(245, 245, 245, 255));
        brush14.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush14);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush8);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
        QBrush brush15(QColor(0, 0, 0, 128));
        brush15.setStyle(Qt::SolidPattern);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Inactive, QPalette::PlaceholderText, brush15);
#endif
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush6);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush14);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush8);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Disabled, QPalette::PlaceholderText, brush15);
#endif
        parentTabWidget->setProperty("tabPalette", QVariant(palette));
        searchTab = new QWidget();
        searchTab->setObjectName("searchTab");
        searchOutputTxt_3 = new QPlainTextEdit(searchTab);
        searchOutputTxt_3->setObjectName("searchOutputTxt_3");
        searchOutputTxt_3->setGeometry(QRect(300, 40, 231, 271));
        searchOutputTxt_3->setReadOnly(true);
        verticalLayoutWidget_8 = new QWidget(searchTab);
        verticalLayoutWidget_8->setObjectName("verticalLayoutWidget_8");
        verticalLayoutWidget_8->setGeometry(QRect(100, 90, 151, 129));
        verticalLayout_9 = new QVBoxLayout(verticalLayoutWidget_8);
        verticalLayout_9->setSpacing(6);
        verticalLayout_9->setObjectName("verticalLayout_9");
        verticalLayout_9->setContentsMargins(0, 0, 0, 0);
        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_9->addItem(verticalSpacer);

        searchLbl = new QLabel(verticalLayoutWidget_8);
        searchLbl->setObjectName("searchLbl");

        verticalLayout_9->addWidget(searchLbl);

        searchLineEdt = new QLineEdit(verticalLayoutWidget_8);
        searchLineEdt->setObjectName("searchLineEdt");

        verticalLayout_9->addWidget(searchLineEdt);

        searchBtn = new QPushButton(verticalLayoutWidget_8);
        searchBtn->setObjectName("searchBtn");

        verticalLayout_9->addWidget(searchBtn);

        searchHelp = new QPushButton(searchTab);
        searchHelp->setObjectName("searchHelp");
        searchHelp->setGeometry(QRect(10, 10, 80, 24));
        exitBtn = new QPushButton(searchTab);
        exitBtn->setObjectName("exitBtn");
        exitBtn->setGeometry(QRect(100, 10, 80, 24));
        parentTabWidget->addTab(searchTab, QString());
        addBookTab = new QWidget();
        addBookTab->setObjectName("addBookTab");
        addInvBtn = new QPushButton(addBookTab);
        addInvBtn->setObjectName("addInvBtn");
        addInvBtn->setGeometry(QRect(410, 160, 111, 41));
        addBookHelp = new QPushButton(addBookTab);
        addBookHelp->setObjectName("addBookHelp");
        addBookHelp->setGeometry(QRect(10, 10, 80, 24));
        exitBtn_2 = new QPushButton(addBookTab);
        exitBtn_2->setObjectName("exitBtn_2");
        exitBtn_2->setGeometry(QRect(100, 10, 80, 24));
        layoutWidget1 = new QWidget(addBookTab);
        layoutWidget1->setObjectName("layoutWidget1");
        layoutWidget1->setGeometry(QRect(10, 60, 302, 32));
        horizontalLayout_7 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_7->setObjectName("horizontalLayout_7");
        horizontalLayout_7->setContentsMargins(0, 0, 0, 0);
        IsbnLbl = new QLabel(layoutWidget1);
        IsbnLbl->setObjectName("IsbnLbl");
        IsbnLbl->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_7->addWidget(IsbnLbl);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_4);

        isbnTxt = new QTextEdit(layoutWidget1);
        isbnTxt->setObjectName("isbnTxt");
        isbnTxt->setMinimumSize(QSize(0, 0));
        isbnTxt->setMaximumSize(QSize(16777215, 30));
        isbnTxt->setTabChangesFocus(true);

        horizontalLayout_7->addWidget(isbnTxt);

        layoutWidget2 = new QWidget(addBookTab);
        layoutWidget2->setObjectName("layoutWidget2");
        layoutWidget2->setGeometry(QRect(10, 90, 302, 32));
        horizontalLayout_11 = new QHBoxLayout(layoutWidget2);
        horizontalLayout_11->setObjectName("horizontalLayout_11");
        horizontalLayout_11->setContentsMargins(0, 0, 0, 0);
        bookTitleLbl = new QLabel(layoutWidget2);
        bookTitleLbl->setObjectName("bookTitleLbl");
        bookTitleLbl->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_11->addWidget(bookTitleLbl);

        horizontalSpacer_5 = new QSpacerItem(13, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_5);

        bookTitleTxt = new QTextEdit(layoutWidget2);
        bookTitleTxt->setObjectName("bookTitleTxt");
        bookTitleTxt->setMinimumSize(QSize(0, 0));
        bookTitleTxt->setMaximumSize(QSize(16777215, 30));
        bookTitleTxt->setTabChangesFocus(true);

        horizontalLayout_11->addWidget(bookTitleTxt);

        layoutWidget3 = new QWidget(addBookTab);
        layoutWidget3->setObjectName("layoutWidget3");
        layoutWidget3->setGeometry(QRect(10, 120, 302, 32));
        horizontalLayout_12 = new QHBoxLayout(layoutWidget3);
        horizontalLayout_12->setObjectName("horizontalLayout_12");
        horizontalLayout_12->setContentsMargins(0, 0, 0, 0);
        authorLbl = new QLabel(layoutWidget3);
        authorLbl->setObjectName("authorLbl");
        authorLbl->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_12->addWidget(authorLbl);

        horizontalSpacer_6 = new QSpacerItem(27, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_12->addItem(horizontalSpacer_6);

        authorTxt = new QTextEdit(layoutWidget3);
        authorTxt->setObjectName("authorTxt");
        authorTxt->setMinimumSize(QSize(0, 0));
        authorTxt->setMaximumSize(QSize(16777215, 30));
        authorTxt->setTabChangesFocus(true);

        horizontalLayout_12->addWidget(authorTxt);

        layoutWidget4 = new QWidget(addBookTab);
        layoutWidget4->setObjectName("layoutWidget4");
        layoutWidget4->setGeometry(QRect(10, 150, 302, 32));
        horizontalLayout_9 = new QHBoxLayout(layoutWidget4);
        horizontalLayout_9->setObjectName("horizontalLayout_9");
        horizontalLayout_9->setContentsMargins(0, 0, 0, 0);
        pubLbl = new QLabel(layoutWidget4);
        pubLbl->setObjectName("pubLbl");
        pubLbl->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_9->addWidget(pubLbl);

        horizontalSpacer_7 = new QSpacerItem(15, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_7);

        pubTxt = new QTextEdit(layoutWidget4);
        pubTxt->setObjectName("pubTxt");
        pubTxt->setMinimumSize(QSize(0, 0));
        pubTxt->setMaximumSize(QSize(16777215, 30));
        pubTxt->setTabChangesFocus(true);

        horizontalLayout_9->addWidget(pubTxt);

        layoutWidget5 = new QWidget(addBookTab);
        layoutWidget5->setObjectName("layoutWidget5");
        layoutWidget5->setGeometry(QRect(10, 180, 302, 32));
        horizontalLayout_10 = new QHBoxLayout(layoutWidget5);
        horizontalLayout_10->setObjectName("horizontalLayout_10");
        horizontalLayout_10->setContentsMargins(0, 0, 0, 0);
        pubYearLbl = new QLabel(layoutWidget5);
        pubYearLbl->setObjectName("pubYearLbl");
        pubYearLbl->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_10->addWidget(pubYearLbl);

        horizontalSpacer_8 = new QSpacerItem(0, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_8);

        pubYearTxt = new QTextEdit(layoutWidget5);
        pubYearTxt->setObjectName("pubYearTxt");
        pubYearTxt->setMinimumSize(QSize(0, 0));
        pubYearTxt->setMaximumSize(QSize(16777215, 30));
        pubYearTxt->setTabChangesFocus(true);

        horizontalLayout_10->addWidget(pubYearTxt);

        layoutWidget6 = new QWidget(addBookTab);
        layoutWidget6->setObjectName("layoutWidget6");
        layoutWidget6->setGeometry(QRect(10, 210, 302, 32));
        horizontalLayout_8 = new QHBoxLayout(layoutWidget6);
        horizontalLayout_8->setObjectName("horizontalLayout_8");
        horizontalLayout_8->setContentsMargins(0, 0, 0, 0);
        genreLbl = new QLabel(layoutWidget6);
        genreLbl->setObjectName("genreLbl");
        genreLbl->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_8->addWidget(genreLbl);

        horizontalSpacer_9 = new QSpacerItem(32, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_9);

        genreTxt = new QTextEdit(layoutWidget6);
        genreTxt->setObjectName("genreTxt");
        genreTxt->setMinimumSize(QSize(0, 0));
        genreTxt->setMaximumSize(QSize(16777215, 30));
        genreTxt->setTabChangesFocus(true);

        horizontalLayout_8->addWidget(genreTxt);

        layoutWidget7 = new QWidget(addBookTab);
        layoutWidget7->setObjectName("layoutWidget7");
        layoutWidget7->setGeometry(QRect(10, 240, 302, 32));
        horizontalLayout_15 = new QHBoxLayout(layoutWidget7);
        horizontalLayout_15->setObjectName("horizontalLayout_15");
        horizontalLayout_15->setSizeConstraint(QLayout::SetNoConstraint);
        horizontalLayout_15->setContentsMargins(0, 0, 0, 0);
        descLbl = new QLabel(layoutWidget7);
        descLbl->setObjectName("descLbl");
        descLbl->setMinimumSize(QSize(0, 30));
        descLbl->setMaximumSize(QSize(16777215, 30));
        descLbl->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_15->addWidget(descLbl);

        horizontalSpacer_12 = new QSpacerItem(3, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_15->addItem(horizontalSpacer_12);

        descTxt = new QTextEdit(layoutWidget7);
        descTxt->setObjectName("descTxt");
        descTxt->setMinimumSize(QSize(0, 0));
        descTxt->setMaximumSize(QSize(16777215, 30));
        descTxt->setTabChangesFocus(true);

        horizontalLayout_15->addWidget(descTxt);

        layoutWidget8 = new QWidget(addBookTab);
        layoutWidget8->setObjectName("layoutWidget8");
        layoutWidget8->setGeometry(QRect(10, 270, 302, 32));
        horizontalLayout_14 = new QHBoxLayout(layoutWidget8);
        horizontalLayout_14->setObjectName("horizontalLayout_14");
        horizontalLayout_14->setContentsMargins(0, 0, 0, 0);
        msrpLbl = new QLabel(layoutWidget8);
        msrpLbl->setObjectName("msrpLbl");
        msrpLbl->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_14->addWidget(msrpLbl);

        horizontalSpacer_11 = new QSpacerItem(32, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_14->addItem(horizontalSpacer_11);

        msrpTxt = new QTextEdit(layoutWidget8);
        msrpTxt->setObjectName("msrpTxt");
        msrpTxt->setMinimumSize(QSize(0, 0));
        msrpTxt->setMaximumSize(QSize(16777215, 30));
        msrpTxt->setTabChangesFocus(true);

        horizontalLayout_14->addWidget(msrpTxt);

        layoutWidget9 = new QWidget(addBookTab);
        layoutWidget9->setObjectName("layoutWidget9");
        layoutWidget9->setGeometry(QRect(10, 300, 302, 32));
        horizontalLayout_13 = new QHBoxLayout(layoutWidget9);
        horizontalLayout_13->setObjectName("horizontalLayout_13");
        horizontalLayout_13->setContentsMargins(0, 0, 0, 0);
        quantLbl = new QLabel(layoutWidget9);
        quantLbl->setObjectName("quantLbl");
        quantLbl->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_13->addWidget(quantLbl);

        horizontalSpacer_10 = new QSpacerItem(17, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_13->addItem(horizontalSpacer_10);

        quantTxt = new QTextEdit(layoutWidget9);
        quantTxt->setObjectName("quantTxt");
        quantTxt->setMinimumSize(QSize(0, 0));
        quantTxt->setMaximumSize(QSize(16777215, 30));
        quantTxt->setTabChangesFocus(true);

        horizontalLayout_13->addWidget(quantTxt);

        parentTabWidget->addTab(addBookTab, QString());
        addBookListTab = new QWidget();
        addBookListTab->setObjectName("addBookListTab");
        verticalLayoutWidget = new QWidget(addBookListTab);
        verticalLayoutWidget->setObjectName("verticalLayoutWidget");
        verticalLayoutWidget->setGeometry(QRect(10, 40, 251, 61));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout_2->setObjectName("verticalLayout_2");
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName("horizontalLayout");
        titleLbl = new QLabel(verticalLayoutWidget);
        titleLbl->setObjectName("titleLbl");

        horizontalLayout->addWidget(titleLbl);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        titleTxt = new QLineEdit(verticalLayoutWidget);
        titleTxt->setObjectName("titleTxt");

        horizontalLayout->addWidget(titleTxt);


        verticalLayout_2->addLayout(horizontalLayout);

        titleSearchBtn = new QPushButton(verticalLayoutWidget);
        titleSearchBtn->setObjectName("titleSearchBtn");

        verticalLayout_2->addWidget(titleSearchBtn);

        verticalLayoutWidget_2 = new QWidget(addBookListTab);
        verticalLayoutWidget_2->setObjectName("verticalLayoutWidget_2");
        verticalLayoutWidget_2->setGeometry(QRect(10, 110, 251, 211));
        verticalLayout_3 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_3->setObjectName("verticalLayout_3");
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        bookList = new QListWidget(verticalLayoutWidget_2);
        bookList->setObjectName("bookList");

        verticalLayout_3->addWidget(bookList);

        addBookBtn = new QPushButton(verticalLayoutWidget_2);
        addBookBtn->setObjectName("addBookBtn");

        verticalLayout_3->addWidget(addBookBtn);

        addBookCartBtn = new QPushButton(verticalLayoutWidget_2);
        addBookCartBtn->setObjectName("addBookCartBtn");

        verticalLayout_3->addWidget(addBookCartBtn);

        bookListHelp = new QPushButton(addBookListTab);
        bookListHelp->setObjectName("bookListHelp");
        bookListHelp->setGeometry(QRect(10, 10, 80, 24));
        verticalLayoutWidget_10 = new QWidget(addBookListTab);
        verticalLayoutWidget_10->setObjectName("verticalLayoutWidget_10");
        verticalLayoutWidget_10->setGeometry(QRect(350, 40, 221, 281));
        verticalLayout_11 = new QVBoxLayout(verticalLayoutWidget_10);
        verticalLayout_11->setObjectName("verticalLayout_11");
        verticalLayout_11->setContentsMargins(0, 0, 0, 0);
        bookListLbl = new QLabel(verticalLayoutWidget_10);
        bookListLbl->setObjectName("bookListLbl");

        verticalLayout_11->addWidget(bookListLbl);

        finalBookList = new QListWidget(verticalLayoutWidget_10);
        finalBookList->setObjectName("finalBookList");

        verticalLayout_11->addWidget(finalBookList);

        removeBookBtn = new QPushButton(verticalLayoutWidget_10);
        removeBookBtn->setObjectName("removeBookBtn");

        verticalLayout_11->addWidget(removeBookBtn);

        saveListBtn = new QPushButton(verticalLayoutWidget_10);
        saveListBtn->setObjectName("saveListBtn");

        verticalLayout_11->addWidget(saveListBtn);

        listExportBtn = new QPushButton(verticalLayoutWidget_10);
        listExportBtn->setObjectName("listExportBtn");

        verticalLayout_11->addWidget(listExportBtn);

        exitBtn_3 = new QPushButton(addBookListTab);
        exitBtn_3->setObjectName("exitBtn_3");
        exitBtn_3->setGeometry(QRect(100, 10, 80, 24));
        parentTabWidget->addTab(addBookListTab, QString());
        shoppingCartTab = new QWidget();
        shoppingCartTab->setObjectName("shoppingCartTab");
        verticalLayoutWidget_3 = new QWidget(shoppingCartTab);
        verticalLayoutWidget_3->setObjectName("verticalLayoutWidget_3");
        verticalLayoutWidget_3->setGeometry(QRect(270, 10, 301, 240));
        verticalLayout_4 = new QVBoxLayout(verticalLayoutWidget_3);
        verticalLayout_4->setObjectName("verticalLayout_4");
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        shoppingList = new QListWidget(verticalLayoutWidget_3);
        shoppingList->setObjectName("shoppingList");

        verticalLayout_4->addWidget(shoppingList);

        verticalLayoutWidget_4 = new QWidget(shoppingCartTab);
        verticalLayoutWidget_4->setObjectName("verticalLayoutWidget_4");
        verticalLayoutWidget_4->setGeometry(QRect(270, 250, 73, 59));
        verticalLayout_5 = new QVBoxLayout(verticalLayoutWidget_4);
        verticalLayout_5->setObjectName("verticalLayout_5");
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        subtotalLbl = new QLabel(verticalLayoutWidget_4);
        subtotalLbl->setObjectName("subtotalLbl");

        verticalLayout_5->addWidget(subtotalLbl);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        subTotalTxt = new QLineEdit(verticalLayoutWidget_4);
        subTotalTxt->setObjectName("subTotalTxt");
        subTotalTxt->setReadOnly(true);

        horizontalLayout_4->addWidget(subTotalTxt);


        verticalLayout_5->addLayout(horizontalLayout_4);

        verticalLayoutWidget_5 = new QWidget(shoppingCartTab);
        verticalLayoutWidget_5->setObjectName("verticalLayoutWidget_5");
        verticalLayoutWidget_5->setGeometry(QRect(380, 250, 73, 59));
        verticalLayout_6 = new QVBoxLayout(verticalLayoutWidget_5);
        verticalLayout_6->setObjectName("verticalLayout_6");
        verticalLayout_6->setContentsMargins(0, 0, 0, 0);
        taxLbl = new QLabel(verticalLayoutWidget_5);
        taxLbl->setObjectName("taxLbl");

        verticalLayout_6->addWidget(taxLbl);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName("horizontalLayout_5");
        taxTxt = new QLineEdit(verticalLayoutWidget_5);
        taxTxt->setObjectName("taxTxt");
        taxTxt->setReadOnly(true);

        horizontalLayout_5->addWidget(taxTxt);


        verticalLayout_6->addLayout(horizontalLayout_5);

        verticalLayoutWidget_6 = new QWidget(shoppingCartTab);
        verticalLayoutWidget_6->setObjectName("verticalLayoutWidget_6");
        verticalLayoutWidget_6->setGeometry(QRect(490, 250, 79, 59));
        verticalLayout_7 = new QVBoxLayout(verticalLayoutWidget_6);
        verticalLayout_7->setObjectName("verticalLayout_7");
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        grandTotalLbl = new QLabel(verticalLayoutWidget_6);
        grandTotalLbl->setObjectName("grandTotalLbl");

        verticalLayout_7->addWidget(grandTotalLbl);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName("horizontalLayout_6");
        grandTotalTxt = new QLineEdit(verticalLayoutWidget_6);
        grandTotalTxt->setObjectName("grandTotalTxt");
        grandTotalTxt->setReadOnly(true);

        horizontalLayout_6->addWidget(grandTotalTxt);


        verticalLayout_7->addLayout(horizontalLayout_6);

        purchaseBtn = new QPushButton(shoppingCartTab);
        purchaseBtn->setObjectName("purchaseBtn");
        purchaseBtn->setGeometry(QRect(370, 320, 101, 24));
        cartHelp = new QPushButton(shoppingCartTab);
        cartHelp->setObjectName("cartHelp");
        cartHelp->setGeometry(QRect(10, 10, 80, 24));
        exitBtn_4 = new QPushButton(shoppingCartTab);
        exitBtn_4->setObjectName("exitBtn_4");
        exitBtn_4->setGeometry(QRect(100, 10, 80, 24));
        layoutWidget10 = new QWidget(shoppingCartTab);
        layoutWidget10->setObjectName("layoutWidget10");
        layoutWidget10->setGeometry(QRect(50, 160, 158, 32));
        horizontalLayout_16 = new QHBoxLayout(layoutWidget10);
        horizontalLayout_16->setObjectName("horizontalLayout_16");
        horizontalLayout_16->setContentsMargins(0, 0, 0, 0);
        emailLbl = new QLabel(layoutWidget10);
        emailLbl->setObjectName("emailLbl");

        horizontalLayout_16->addWidget(emailLbl);

        horizontalSpacer_2 = new QSpacerItem(5, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_16->addItem(horizontalSpacer_2);

        emailTxt = new QTextEdit(layoutWidget10);
        emailTxt->setObjectName("emailTxt");
        emailTxt->setMinimumSize(QSize(0, 30));
        emailTxt->setMaximumSize(QSize(16777215, 30));
        emailTxt->setTabChangesFocus(true);

        horizontalLayout_16->addWidget(emailTxt);

        layoutWidget11 = new QWidget(shoppingCartTab);
        layoutWidget11->setObjectName("layoutWidget11");
        layoutWidget11->setGeometry(QRect(50, 130, 158, 32));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget11);
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        nameLbl = new QLabel(layoutWidget11);
        nameLbl->setObjectName("nameLbl");

        horizontalLayout_2->addWidget(nameLbl);

        nameTxt = new QTextEdit(layoutWidget11);
        nameTxt->setObjectName("nameTxt");
        nameTxt->setMinimumSize(QSize(0, 30));
        nameTxt->setMaximumSize(QSize(16777215, 30));
        nameTxt->setTabChangesFocus(true);

        horizontalLayout_2->addWidget(nameTxt);

        parentTabWidget->addTab(shoppingCartTab, QString());
        adminTab = new QWidget();
        adminTab->setObjectName("adminTab");
        verticalLayoutWidget_7 = new QWidget(adminTab);
        verticalLayoutWidget_7->setObjectName("verticalLayoutWidget_7");
        verticalLayoutWidget_7->setGeometry(QRect(180, 100, 201, 131));
        verticalLayout_8 = new QVBoxLayout(verticalLayoutWidget_7);
        verticalLayout_8->setObjectName("verticalLayout_8");
        verticalLayout_8->setContentsMargins(0, 0, 0, 0);
        addUserBtn = new QPushButton(verticalLayoutWidget_7);
        addUserBtn->setObjectName("addUserBtn");

        verticalLayout_8->addWidget(addUserBtn);

        deleteUserBtn = new QPushButton(verticalLayoutWidget_7);
        deleteUserBtn->setObjectName("deleteUserBtn");

        verticalLayout_8->addWidget(deleteUserBtn);

        changePassBtn = new QPushButton(verticalLayoutWidget_7);
        changePassBtn->setObjectName("changePassBtn");

        verticalLayout_8->addWidget(changePassBtn);

        adminHelp = new QPushButton(adminTab);
        adminHelp->setObjectName("adminHelp");
        adminHelp->setGeometry(QRect(10, 10, 80, 24));
        exitBtn_5 = new QPushButton(adminTab);
        exitBtn_5->setObjectName("exitBtn_5");
        exitBtn_5->setGeometry(QRect(100, 10, 80, 24));
        parentTabWidget->addTab(adminTab, QString());
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 591, 21));
        fileMenu = new QMenu(menubar);
        fileMenu->setObjectName("fileMenu");
        editList = new QMenu(menubar);
        editList->setObjectName("editList");
        menuHelp = new QMenu(menubar);
        menuHelp->setObjectName("menuHelp");
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        statusbar->setBaseSize(QSize(10, 10));
        statusbar->setAutoFillBackground(false);
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(fileMenu->menuAction());
        menubar->addAction(editList->menuAction());
        menubar->addAction(menuHelp->menuAction());
        fileMenu->addAction(actionNotes);
        editList->addAction(actionPreferences);
        menuHelp->addAction(actionHardware_Info);

        retranslateUi(MainWindow);
        QObject::connect(searchBtn, SIGNAL(clicked()), MainWindow, SLOT(search_inventory()));
        QObject::connect(searchHelp, SIGNAL(clicked()), MainWindow, SLOT(showHelpWindow()));
        QObject::connect(bookListHelp, SIGNAL(clicked()), MainWindow, SLOT(showHelpWindow()));
        QObject::connect(cartHelp, SIGNAL(clicked()), MainWindow, SLOT(showHelpWindow()));
        QObject::connect(adminHelp, SIGNAL(clicked()), MainWindow, SLOT(showHelpWindow()));
        QObject::connect(addInvBtn, SIGNAL(clicked()), MainWindow, SLOT(addBookToInventory()));
        QObject::connect(addBookHelp, SIGNAL(clicked()), MainWindow, SLOT(showHelpWindow()));
        QObject::connect(titleSearchBtn, SIGNAL(clicked()), MainWindow, SLOT(search_inventory()));
        QObject::connect(addBookBtn, SIGNAL(clicked()), MainWindow, SLOT(addBookToListTextBox()));
        QObject::connect(saveListBtn, SIGNAL(clicked()), MainWindow, SLOT(saveListToDb()));
        QObject::connect(listExportBtn, SIGNAL(clicked()), MainWindow, SLOT(exportListToTxt()));
        QObject::connect(removeBookBtn, SIGNAL(clicked()), MainWindow, SLOT(removeBookFromList()));
        QObject::connect(addBookCartBtn, SIGNAL(clicked()), MainWindow, SLOT(addBookToShoppingList()));
        QObject::connect(purchaseBtn, SIGNAL(clicked()), MainWindow, SLOT(purchaseBooks()));
        QObject::connect(exitBtn, &QPushButton::clicked, MainWindow, qOverload<>(&QMainWindow::close));
        QObject::connect(exitBtn_2, &QPushButton::clicked, MainWindow, qOverload<>(&QMainWindow::close));
        QObject::connect(exitBtn_3, &QPushButton::clicked, MainWindow, qOverload<>(&QMainWindow::close));
        QObject::connect(exitBtn_4, &QPushButton::clicked, MainWindow, qOverload<>(&QMainWindow::close));
        QObject::connect(exitBtn_5, &QPushButton::clicked, MainWindow, qOverload<>(&QMainWindow::close));

        parentTabWidget->setCurrentIndex(3);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Book Store", nullptr));
        actionSearcher->setText(QCoreApplication::translate("MainWindow", "Searcher", nullptr));
        actionAdd_Book->setText(QCoreApplication::translate("MainWindow", "Add Book", nullptr));
        actionAdd_to_Cart->setText(QCoreApplication::translate("MainWindow", "Add to Cart", nullptr));
        actionHardware_Info->setText(QCoreApplication::translate("MainWindow", "Hardware Info", nullptr));
        actionNotes->setText(QCoreApplication::translate("MainWindow", "Notes", nullptr));
        actionPreferences->setText(QCoreApplication::translate("MainWindow", "Preferences", nullptr));
        searchLbl->setText(QCoreApplication::translate("MainWindow", "Title Search", nullptr));
        searchBtn->setText(QCoreApplication::translate("MainWindow", "Search", nullptr));
        searchHelp->setText(QCoreApplication::translate("MainWindow", "Help", nullptr));
        exitBtn->setText(QCoreApplication::translate("MainWindow", "Exit App", nullptr));
        parentTabWidget->setTabText(parentTabWidget->indexOf(searchTab), QCoreApplication::translate("MainWindow", "Book Search", nullptr));
        addInvBtn->setText(QCoreApplication::translate("MainWindow", "Add To Inventory", nullptr));
        addBookHelp->setText(QCoreApplication::translate("MainWindow", "Help", nullptr));
        exitBtn_2->setText(QCoreApplication::translate("MainWindow", "Exit App", nullptr));
        IsbnLbl->setText(QCoreApplication::translate("MainWindow", "ISBN:", nullptr));
        bookTitleLbl->setText(QCoreApplication::translate("MainWindow", "Book Title:", nullptr));
        authorLbl->setText(QCoreApplication::translate("MainWindow", "Author:", nullptr));
        pubLbl->setText(QCoreApplication::translate("MainWindow", "Publisher:", nullptr));
        pubYearLbl->setText(QCoreApplication::translate("MainWindow", "Publication Year:", nullptr));
        genreLbl->setText(QCoreApplication::translate("MainWindow", "Genre:", nullptr));
        descLbl->setText(QCoreApplication::translate("MainWindow", "Description:", nullptr));
        msrpLbl->setText(QCoreApplication::translate("MainWindow", "MSRP:", nullptr));
        quantLbl->setText(QCoreApplication::translate("MainWindow", "Quantity:", nullptr));
        parentTabWidget->setTabText(parentTabWidget->indexOf(addBookTab), QCoreApplication::translate("MainWindow", "Add Book", nullptr));
        titleLbl->setText(QCoreApplication::translate("MainWindow", "Book Title", nullptr));
        titleSearchBtn->setText(QCoreApplication::translate("MainWindow", "Search", nullptr));
        addBookBtn->setText(QCoreApplication::translate("MainWindow", "Add Book To List >>", nullptr));
        addBookCartBtn->setText(QCoreApplication::translate("MainWindow", "Add Book To Shopping Cart", nullptr));
        bookListHelp->setText(QCoreApplication::translate("MainWindow", "Help", nullptr));
        bookListLbl->setText(QCoreApplication::translate("MainWindow", "Current Book List", nullptr));
        removeBookBtn->setText(QCoreApplication::translate("MainWindow", "<< Remove Book From List", nullptr));
        saveListBtn->setText(QCoreApplication::translate("MainWindow", "Save List", nullptr));
        listExportBtn->setText(QCoreApplication::translate("MainWindow", "Export List To Text File", nullptr));
        exitBtn_3->setText(QCoreApplication::translate("MainWindow", "Exit App", nullptr));
        parentTabWidget->setTabText(parentTabWidget->indexOf(addBookListTab), QCoreApplication::translate("MainWindow", "Book List", nullptr));
        subtotalLbl->setText(QCoreApplication::translate("MainWindow", "Subtotal", nullptr));
        taxLbl->setText(QCoreApplication::translate("MainWindow", "Tax", nullptr));
        grandTotalLbl->setText(QCoreApplication::translate("MainWindow", "Grand Total", nullptr));
        purchaseBtn->setText(QCoreApplication::translate("MainWindow", "Purchase Books", nullptr));
        cartHelp->setText(QCoreApplication::translate("MainWindow", "Help", nullptr));
        exitBtn_4->setText(QCoreApplication::translate("MainWindow", "Exit App", nullptr));
        emailLbl->setText(QCoreApplication::translate("MainWindow", "Email:", nullptr));
        nameLbl->setText(QCoreApplication::translate("MainWindow", "Name: ", nullptr));
        parentTabWidget->setTabText(parentTabWidget->indexOf(shoppingCartTab), QCoreApplication::translate("MainWindow", "Shopping Cart", nullptr));
        addUserBtn->setText(QCoreApplication::translate("MainWindow", "Add User", nullptr));
        deleteUserBtn->setText(QCoreApplication::translate("MainWindow", "Delete User", nullptr));
        changePassBtn->setText(QCoreApplication::translate("MainWindow", "Change User Password", nullptr));
        adminHelp->setText(QCoreApplication::translate("MainWindow", "Help", nullptr));
        exitBtn_5->setText(QCoreApplication::translate("MainWindow", "Exit App", nullptr));
        parentTabWidget->setTabText(parentTabWidget->indexOf(adminTab), QCoreApplication::translate("MainWindow", "Admin Menu", nullptr));
        fileMenu->setTitle(QCoreApplication::translate("MainWindow", "File", nullptr));
        editList->setTitle(QCoreApplication::translate("MainWindow", "Edit", nullptr));
        menuHelp->setTitle(QCoreApplication::translate("MainWindow", "Help", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
