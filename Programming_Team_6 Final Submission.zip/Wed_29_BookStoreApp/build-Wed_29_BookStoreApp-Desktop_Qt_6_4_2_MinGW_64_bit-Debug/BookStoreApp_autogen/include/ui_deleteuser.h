/********************************************************************************
** Form generated from reading UI file 'deleteuser.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DELETEUSER_H
#define UI_DELETEUSER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_deleteuser
{
public:
    QLabel *deleteUserTitle;
    QTextEdit *deleteUserTxt;
    QPushButton *deleteCancelBtn;
    QPushButton *deleteOkBtn;
    QLabel *deleteUserLbl;

    void setupUi(QDialog *deleteuser)
    {
        if (deleteuser->objectName().isEmpty())
            deleteuser->setObjectName("deleteuser");
        deleteuser->resize(400, 300);
        deleteUserTitle = new QLabel(deleteuser);
        deleteUserTitle->setObjectName("deleteUserTitle");
        deleteUserTitle->setGeometry(QRect(130, 20, 141, 41));
        QFont font;
        font.setPointSize(20);
        deleteUserTitle->setFont(font);
        deleteUserTxt = new QTextEdit(deleteuser);
        deleteUserTxt->setObjectName("deleteUserTxt");
        deleteUserTxt->setGeometry(QRect(140, 110, 104, 31));
        deleteCancelBtn = new QPushButton(deleteuser);
        deleteCancelBtn->setObjectName("deleteCancelBtn");
        deleteCancelBtn->setGeometry(QRect(100, 180, 80, 24));
        deleteOkBtn = new QPushButton(deleteuser);
        deleteOkBtn->setObjectName("deleteOkBtn");
        deleteOkBtn->setGeometry(QRect(210, 180, 80, 24));
        deleteUserLbl = new QLabel(deleteuser);
        deleteUserLbl->setObjectName("deleteUserLbl");
        deleteUserLbl->setGeometry(QRect(140, 80, 61, 21));

        retranslateUi(deleteuser);
        QObject::connect(deleteCancelBtn, &QPushButton::clicked, deleteuser, qOverload<>(&QDialog::close));
        QObject::connect(deleteOkBtn, SIGNAL(clicked()), deleteuser, SLOT(deleteUserFromDb()));

        QMetaObject::connectSlotsByName(deleteuser);
    } // setupUi

    void retranslateUi(QDialog *deleteuser)
    {
        deleteuser->setWindowTitle(QCoreApplication::translate("deleteuser", "Dialog", nullptr));
        deleteUserTitle->setText(QCoreApplication::translate("deleteuser", "Delete User", nullptr));
        deleteCancelBtn->setText(QCoreApplication::translate("deleteuser", "Cancel", nullptr));
        deleteOkBtn->setText(QCoreApplication::translate("deleteuser", "Delete", nullptr));
        deleteUserLbl->setText(QCoreApplication::translate("deleteuser", "Username", nullptr));
    } // retranslateUi

};

namespace Ui {
    class deleteuser: public Ui_deleteuser {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DELETEUSER_H
