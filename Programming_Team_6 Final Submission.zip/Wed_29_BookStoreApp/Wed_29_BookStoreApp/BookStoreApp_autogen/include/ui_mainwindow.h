/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionSearcher;
    QAction *actionAdd_Book;
    QAction *actionAdd_to_Cart;
    QAction *actionHardware_Info;
    QAction *actionNotes;
    QWidget *centralwidget;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QTabWidget *tabWidget;
    QWidget *searchTab;
    QPlainTextEdit *searchOutputTxt_3;
    QWidget *verticalLayoutWidget_8;
    QVBoxLayout *verticalLayout_9;
    QLabel *searchLbl;
    QLineEdit *searchLineEdt;
    QPushButton *searchBtn;
    QPushButton *exitBtn;
    QPushButton *searchHelp;
    QWidget *addBookTab;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QSpacerItem *horizontalSpacer;
    QLineEdit *lineEdit;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QSpacerItem *horizontalSpacer_2;
    QLineEdit *lineEdit_2;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QSpacerItem *horizontalSpacer_3;
    QLineEdit *lineEdit_3;
    QPushButton *pushButton;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_3;
    QListWidget *listWidget;
    QPushButton *addBookBtn;
    QPushButton *bookAddHelp;
    QWidget *shoppingCartTab;
    QWidget *verticalLayoutWidget_3;
    QVBoxLayout *verticalLayout_4;
    QPlainTextEdit *plainTextEdit;
    QWidget *verticalLayoutWidget_4;
    QVBoxLayout *verticalLayout_5;
    QLabel *subtotalLbl;
    QHBoxLayout *horizontalLayout_4;
    QLineEdit *lineEdit_4;
    QWidget *verticalLayoutWidget_5;
    QVBoxLayout *verticalLayout_6;
    QLabel *taxLbl;
    QHBoxLayout *horizontalLayout_5;
    QLineEdit *lineEdit_5;
    QWidget *verticalLayoutWidget_6;
    QVBoxLayout *verticalLayout_7;
    QLabel *grandTotalLbl;
    QHBoxLayout *horizontalLayout_6;
    QLineEdit *lineEdit_6;
    QPushButton *purchaseBtn;
    QPushButton *cartHelp;
    QWidget *adminTab;
    QWidget *verticalLayoutWidget_7;
    QVBoxLayout *verticalLayout_8;
    QPushButton *addUserBtn;
    QPushButton *deleteUserBtn;
    QPushButton *changePassBtn;
    QPushButton *adminHelp;
    QMenuBar *menubar;
    QMenu *fileMenu;
    QMenu *editList;
    QMenu *menuHelp;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->setEnabled(true);
        MainWindow->resize(591, 429);
        actionSearcher = new QAction(MainWindow);
        actionSearcher->setObjectName("actionSearcher");
        actionAdd_Book = new QAction(MainWindow);
        actionAdd_Book->setObjectName("actionAdd_Book");
        actionAdd_to_Cart = new QAction(MainWindow);
        actionAdd_to_Cart->setObjectName("actionAdd_to_Cart");
        actionHardware_Info = new QAction(MainWindow);
        actionHardware_Info->setObjectName("actionHardware_Info");
        actionNotes = new QAction(MainWindow);
        actionNotes->setObjectName("actionNotes");
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(140, 120, 129, 126));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName("tabWidget");
        tabWidget->setGeometry(QRect(0, 0, 591, 401));
        searchTab = new QWidget();
        searchTab->setObjectName("searchTab");
        searchOutputTxt_3 = new QPlainTextEdit(searchTab);
        searchOutputTxt_3->setObjectName("searchOutputTxt_3");
        searchOutputTxt_3->setGeometry(QRect(300, 40, 231, 271));
        searchOutputTxt_3->setReadOnly(true);
        verticalLayoutWidget_8 = new QWidget(searchTab);
        verticalLayoutWidget_8->setObjectName("verticalLayoutWidget_8");
        verticalLayoutWidget_8->setGeometry(QRect(100, 110, 151, 129));
        verticalLayout_9 = new QVBoxLayout(verticalLayoutWidget_8);
        verticalLayout_9->setObjectName("verticalLayout_9");
        verticalLayout_9->setContentsMargins(0, 0, 0, 0);
        searchLbl = new QLabel(verticalLayoutWidget_8);
        searchLbl->setObjectName("searchLbl");

        verticalLayout_9->addWidget(searchLbl);

        searchLineEdt = new QLineEdit(verticalLayoutWidget_8);
        searchLineEdt->setObjectName("searchLineEdt");

        verticalLayout_9->addWidget(searchLineEdt);

        searchBtn = new QPushButton(verticalLayoutWidget_8);
        searchBtn->setObjectName("searchBtn");

        verticalLayout_9->addWidget(searchBtn);

        exitBtn = new QPushButton(verticalLayoutWidget_8);
        exitBtn->setObjectName("exitBtn");

        verticalLayout_9->addWidget(exitBtn);

        searchHelp = new QPushButton(searchTab);
        searchHelp->setObjectName("searchHelp");
        searchHelp->setGeometry(QRect(10, 10, 80, 24));
        tabWidget->addTab(searchTab, QString());
        addBookTab = new QWidget();
        addBookTab->setObjectName("addBookTab");
        verticalLayoutWidget = new QWidget(addBookTab);
        verticalLayoutWidget->setObjectName("verticalLayoutWidget");
        verticalLayoutWidget->setGeometry(QRect(20, 110, 271, 142));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout_2->setObjectName("verticalLayout_2");
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName("horizontalLayout");
        label = new QLabel(verticalLayoutWidget);
        label->setObjectName("label");

        horizontalLayout->addWidget(label);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        lineEdit = new QLineEdit(verticalLayoutWidget);
        lineEdit->setObjectName("lineEdit");

        horizontalLayout->addWidget(lineEdit);


        verticalLayout_2->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        label_2 = new QLabel(verticalLayoutWidget);
        label_2->setObjectName("label_2");

        horizontalLayout_2->addWidget(label_2);

        horizontalSpacer_2 = new QSpacerItem(65, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        lineEdit_2 = new QLineEdit(verticalLayoutWidget);
        lineEdit_2->setObjectName("lineEdit_2");

        horizontalLayout_2->addWidget(lineEdit_2);


        verticalLayout_2->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        label_3 = new QLabel(verticalLayoutWidget);
        label_3->setObjectName("label_3");

        horizontalLayout_3->addWidget(label_3);

        horizontalSpacer_3 = new QSpacerItem(15, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_3);

        lineEdit_3 = new QLineEdit(verticalLayoutWidget);
        lineEdit_3->setObjectName("lineEdit_3");

        horizontalLayout_3->addWidget(lineEdit_3);


        verticalLayout_2->addLayout(horizontalLayout_3);

        pushButton = new QPushButton(verticalLayoutWidget);
        pushButton->setObjectName("pushButton");

        verticalLayout_2->addWidget(pushButton);

        verticalLayoutWidget_2 = new QWidget(addBookTab);
        verticalLayoutWidget_2->setObjectName("verticalLayoutWidget_2");
        verticalLayoutWidget_2->setGeometry(QRect(310, 80, 251, 211));
        verticalLayout_3 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_3->setObjectName("verticalLayout_3");
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        listWidget = new QListWidget(verticalLayoutWidget_2);
        listWidget->setObjectName("listWidget");

        verticalLayout_3->addWidget(listWidget);

        addBookBtn = new QPushButton(verticalLayoutWidget_2);
        addBookBtn->setObjectName("addBookBtn");

        verticalLayout_3->addWidget(addBookBtn);

        bookAddHelp = new QPushButton(addBookTab);
        bookAddHelp->setObjectName("bookAddHelp");
        bookAddHelp->setGeometry(QRect(10, 10, 80, 24));
        tabWidget->addTab(addBookTab, QString());
        shoppingCartTab = new QWidget();
        shoppingCartTab->setObjectName("shoppingCartTab");
        verticalLayoutWidget_3 = new QWidget(shoppingCartTab);
        verticalLayoutWidget_3->setObjectName("verticalLayoutWidget_3");
        verticalLayoutWidget_3->setGeometry(QRect(140, 20, 301, 231));
        verticalLayout_4 = new QVBoxLayout(verticalLayoutWidget_3);
        verticalLayout_4->setObjectName("verticalLayout_4");
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        plainTextEdit = new QPlainTextEdit(verticalLayoutWidget_3);
        plainTextEdit->setObjectName("plainTextEdit");

        verticalLayout_4->addWidget(plainTextEdit);

        verticalLayoutWidget_4 = new QWidget(shoppingCartTab);
        verticalLayoutWidget_4->setObjectName("verticalLayoutWidget_4");
        verticalLayoutWidget_4->setGeometry(QRect(140, 250, 73, 59));
        verticalLayout_5 = new QVBoxLayout(verticalLayoutWidget_4);
        verticalLayout_5->setObjectName("verticalLayout_5");
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        subtotalLbl = new QLabel(verticalLayoutWidget_4);
        subtotalLbl->setObjectName("subtotalLbl");

        verticalLayout_5->addWidget(subtotalLbl);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        lineEdit_4 = new QLineEdit(verticalLayoutWidget_4);
        lineEdit_4->setObjectName("lineEdit_4");
        lineEdit_4->setReadOnly(true);

        horizontalLayout_4->addWidget(lineEdit_4);


        verticalLayout_5->addLayout(horizontalLayout_4);

        verticalLayoutWidget_5 = new QWidget(shoppingCartTab);
        verticalLayoutWidget_5->setObjectName("verticalLayoutWidget_5");
        verticalLayoutWidget_5->setGeometry(QRect(260, 250, 73, 59));
        verticalLayout_6 = new QVBoxLayout(verticalLayoutWidget_5);
        verticalLayout_6->setObjectName("verticalLayout_6");
        verticalLayout_6->setContentsMargins(0, 0, 0, 0);
        taxLbl = new QLabel(verticalLayoutWidget_5);
        taxLbl->setObjectName("taxLbl");

        verticalLayout_6->addWidget(taxLbl);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName("horizontalLayout_5");
        lineEdit_5 = new QLineEdit(verticalLayoutWidget_5);
        lineEdit_5->setObjectName("lineEdit_5");
        lineEdit_5->setReadOnly(true);

        horizontalLayout_5->addWidget(lineEdit_5);


        verticalLayout_6->addLayout(horizontalLayout_5);

        verticalLayoutWidget_6 = new QWidget(shoppingCartTab);
        verticalLayoutWidget_6->setObjectName("verticalLayoutWidget_6");
        verticalLayoutWidget_6->setGeometry(QRect(380, 250, 79, 59));
        verticalLayout_7 = new QVBoxLayout(verticalLayoutWidget_6);
        verticalLayout_7->setObjectName("verticalLayout_7");
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        grandTotalLbl = new QLabel(verticalLayoutWidget_6);
        grandTotalLbl->setObjectName("grandTotalLbl");

        verticalLayout_7->addWidget(grandTotalLbl);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName("horizontalLayout_6");
        lineEdit_6 = new QLineEdit(verticalLayoutWidget_6);
        lineEdit_6->setObjectName("lineEdit_6");
        lineEdit_6->setReadOnly(true);

        horizontalLayout_6->addWidget(lineEdit_6);


        verticalLayout_7->addLayout(horizontalLayout_6);

        purchaseBtn = new QPushButton(shoppingCartTab);
        purchaseBtn->setObjectName("purchaseBtn");
        purchaseBtn->setGeometry(QRect(240, 310, 101, 24));
        cartHelp = new QPushButton(shoppingCartTab);
        cartHelp->setObjectName("cartHelp");
        cartHelp->setGeometry(QRect(10, 10, 80, 24));
        tabWidget->addTab(shoppingCartTab, QString());
        adminTab = new QWidget();
        adminTab->setObjectName("adminTab");
        verticalLayoutWidget_7 = new QWidget(adminTab);
        verticalLayoutWidget_7->setObjectName("verticalLayoutWidget_7");
        verticalLayoutWidget_7->setGeometry(QRect(180, 100, 201, 131));
        verticalLayout_8 = new QVBoxLayout(verticalLayoutWidget_7);
        verticalLayout_8->setObjectName("verticalLayout_8");
        verticalLayout_8->setContentsMargins(0, 0, 0, 0);
        addUserBtn = new QPushButton(verticalLayoutWidget_7);
        addUserBtn->setObjectName("addUserBtn");

        verticalLayout_8->addWidget(addUserBtn);

        deleteUserBtn = new QPushButton(verticalLayoutWidget_7);
        deleteUserBtn->setObjectName("deleteUserBtn");

        verticalLayout_8->addWidget(deleteUserBtn);

        changePassBtn = new QPushButton(verticalLayoutWidget_7);
        changePassBtn->setObjectName("changePassBtn");

        verticalLayout_8->addWidget(changePassBtn);

        adminHelp = new QPushButton(adminTab);
        adminHelp->setObjectName("adminHelp");
        adminHelp->setGeometry(QRect(10, 10, 80, 24));
        tabWidget->addTab(adminTab, QString());
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 591, 26));
        fileMenu = new QMenu(menubar);
        fileMenu->setObjectName("fileMenu");
        editList = new QMenu(menubar);
        editList->setObjectName("editList");
        menuHelp = new QMenu(menubar);
        menuHelp->setObjectName("menuHelp");
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        statusbar->setBaseSize(QSize(10, 10));
        statusbar->setAutoFillBackground(false);
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(fileMenu->menuAction());
        menubar->addAction(editList->menuAction());
        menubar->addAction(menuHelp->menuAction());
        fileMenu->addAction(actionNotes);
        menuHelp->addAction(actionHardware_Info);

        retranslateUi(MainWindow);
        QObject::connect(exitBtn, &QPushButton::clicked, MainWindow, qOverload<>(&QMainWindow::close));
        QObject::connect(searchBtn, SIGNAL(clicked()), MainWindow, SLOT(search_inventory()));
        QObject::connect(searchHelp, SIGNAL(clicked()), MainWindow, SLOT(showHelpWindow()));
        QObject::connect(bookAddHelp, SIGNAL(clicked()), MainWindow, SLOT(showHelpWindow()));
        QObject::connect(cartHelp, SIGNAL(clicked()), MainWindow, SLOT(showHelpWindow()));
        QObject::connect(adminHelp, SIGNAL(clicked()), MainWindow, SLOT(showHelpWindow()));

        tabWidget->setCurrentIndex(3);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Book Store", nullptr));
        actionSearcher->setText(QCoreApplication::translate("MainWindow", "Searcher", nullptr));
        actionAdd_Book->setText(QCoreApplication::translate("MainWindow", "Add Book", nullptr));
        actionAdd_to_Cart->setText(QCoreApplication::translate("MainWindow", "Add to Cart", nullptr));
        actionHardware_Info->setText(QCoreApplication::translate("MainWindow", "Hardware Info", nullptr));
        actionNotes->setText(QCoreApplication::translate("MainWindow", "Notes", nullptr));
        searchLbl->setText(QCoreApplication::translate("MainWindow", "Title Search", nullptr));
        searchBtn->setText(QCoreApplication::translate("MainWindow", "Search", nullptr));
        exitBtn->setText(QCoreApplication::translate("MainWindow", "Exit", nullptr));
        searchHelp->setText(QCoreApplication::translate("MainWindow", "Help", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(searchTab), QCoreApplication::translate("MainWindow", "Book Search", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "Book Name", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Author", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "Publication Date", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "Search", nullptr));
        addBookBtn->setText(QCoreApplication::translate("MainWindow", "Add Book To List", nullptr));
        bookAddHelp->setText(QCoreApplication::translate("MainWindow", "Help", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(addBookTab), QCoreApplication::translate("MainWindow", "Book Add", nullptr));
        subtotalLbl->setText(QCoreApplication::translate("MainWindow", "Subtotal", nullptr));
        taxLbl->setText(QCoreApplication::translate("MainWindow", "Tax", nullptr));
        grandTotalLbl->setText(QCoreApplication::translate("MainWindow", "Grand Total", nullptr));
        purchaseBtn->setText(QCoreApplication::translate("MainWindow", "Purchase Books", nullptr));
        cartHelp->setText(QCoreApplication::translate("MainWindow", "Help", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(shoppingCartTab), QCoreApplication::translate("MainWindow", "Shopping Cart", nullptr));
        addUserBtn->setText(QCoreApplication::translate("MainWindow", "Add User", nullptr));
        deleteUserBtn->setText(QCoreApplication::translate("MainWindow", "Delete User", nullptr));
        changePassBtn->setText(QCoreApplication::translate("MainWindow", "Change User Password", nullptr));
        adminHelp->setText(QCoreApplication::translate("MainWindow", "Help", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(adminTab), QCoreApplication::translate("MainWindow", "Admin Menu", nullptr));
        fileMenu->setTitle(QCoreApplication::translate("MainWindow", "File", nullptr));
        editList->setTitle(QCoreApplication::translate("MainWindow", "Edit", nullptr));
        menuHelp->setTitle(QCoreApplication::translate("MainWindow", "Help", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
